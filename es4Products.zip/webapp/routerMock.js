sap.ui.define(['sap/m/routing/Router'], function(Router) {
	"use strict";
	return Router.extend("sap.hana.uis.flp.routing.Router", {
	});
}, true);